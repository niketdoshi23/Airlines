import { Card,Row,Col,Form, Input } from "antd";
import { Outlet, Link } from "react-router-dom";

const HomePage = () => {
    return ( 
        <>
        <Card>
            <Form>
                <Row>
                <Col span="24">
                <Form.Item label="Name">
                <Input />

                </Form.Item>
                </Col>
            </Row>
            </Form>
            <Link to="/register">For Airways registration visit us!</Link>
            <p>
            <Link to="/airlines">Click here to know about our Airlines!</Link>
            </p>
            <p>
            <Link to="/create-passenger">For Passenger registration visit us!</Link>
            </p>
            <p>
            <Link to="/passenger">Click here to know about our customers!</Link>
            </p>
        </Card>
        </>
     );
}
 
export default HomePage;