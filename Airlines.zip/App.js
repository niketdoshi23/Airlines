import CreateAirlines from "./Airlines/create-airlines.jsx";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Airlines/Airlines.jsx";
import Passenger from "./Passenger/passenger.jsx";
import CreatePassenger from "./Passenger/create-passenger.jsx";
import HomePage from "./home-page.jsx";
import Airlines from "./Airlines/Airlines.jsx";
function App() {
  return (
    <div className="App">
    <BrowserRouter>
    <Routes>
    <Route exact path="/" element={<HomePage />} />
      <Route exact path="/register" element={<CreateAirlines />}/>
      <Route exact path="/airlines" element={<Airlines />}></Route>
      <Route exact path="/passenger" element={<Passenger />}/>
      <Route exact path="/create-passenger" element={<CreatePassenger />}/>
    </Routes>
    </BrowserRouter>
    </div>
  );
}

export default App;
