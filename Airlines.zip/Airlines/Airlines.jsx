import { Button, Space, Table, Tag, Modal } from "antd";
import axios from "axios";
import { InfoCircleOutlined,EditOutlined } from "@ant-design/icons";
import AirlinesInfo from "./airlines-info";
import EditAirlines from "./edit-airlines";
import { useState,useEffect } from "react";
import { Spin } from "antd";
import { Outlet, Link } from "react-router-dom";
import "./Airlines.css";

const Airlines = () => {
  const [isAirwaysInfoAvailable, setIsAirwaysInfoAvailable] = useState(false);
  const [airwaysInfo, setAirwaysInfo] = useState([]);
  const [airwaysById, setAirwaysById] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editAirlinesData,setEditAIrlinesData]=useState({});
  const onClickInfo = (data) => {
    setAirwaysById(data);
    setIsModalOpen(true);
    
  };
  const onClickEdit=(data)=>{
    setEditAIrlinesData(data);
    setIsEditModalOpen(true);
    console.log(data)
  }

  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const column = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
    },
    {
      title: "Established",
      dataIndex: "established",
      key: "established",
    },
    {
      title: "Country",
      dataIndex: "country",
      key: "country",
    },
    {
      title: "Headquaters",
      dataIndex: "head_quaters",
      key: "head_quaters",
    },
    {
      title: "Slogan",
      dataIndex: "slogan",
      key: "slogan",
    },
    {
      title: "Website",
      dataIndex: "website",
      key: "website",
    },
    {
      title: "Action",
      dataIndex: "action",
      key: "action",
      render: (_, record) => (
        <>
          <Space>
            <Button
              icon={<InfoCircleOutlined />}
              onClick={() => onClickInfo(record)}
            />
            <Button icon={<EditOutlined />} onClick={()=>onClickEdit(record)}></Button>
          </Space>
        </>
      ),
    },
  ];

  useEffect(() => {
    axios
    .get("https://api.instantwebtools.net/v1/airlines")
    .then((response) => {
      setIsAirwaysInfoAvailable(false);
      if (response) {
        setIsAirwaysInfoAvailable(true);
        setAirwaysInfo((response?.data).filter((x) => x.id != null));
      }
    })
    .catch((error) => {
      setIsAirwaysInfoAvailable(true);
      console.log(error);
    });
  }, [])

  const editHandleOk=()=>{

  }

  const editHandleCancel=()=>{
    setIsEditModalOpen(false);
  }
  
 
  return (
    <>
      {isAirwaysInfoAvailable ? (
        <Table columns={column} dataSource={airwaysInfo} />
      ) : (
        <Spin className="spin" />
      )}
      <Modal
        title="Airways Information"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <AirlinesInfo airwaysById={airwaysById} />
      </Modal>

      <Modal title="Airways Information" footer={false} width={600}  open={isEditModalOpen}
        onOk={editHandleOk}
        onCancel={editHandleCancel} >
      <EditAirlines
          editAirlinesData={editAirlinesData}
          setIsEditModalOpen={setIsEditModalOpen}
        />
    </Modal>
    </>
  );
};

export default Airlines;
