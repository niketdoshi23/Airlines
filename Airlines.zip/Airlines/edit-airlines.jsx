import { useState,useEffect } from "react";
import { Button, Checkbox, Form, Input, Row, Col } from "antd";
import axios from "axios";

const EditAirlines = (props) => {
  const [editForm] = Form.useForm();
  console.log(props.editAirlinesData.name)
  useEffect(() => {
      editForm.setFieldsValue({
          name:props.editAirlinesData.name,
          country:props.editAirlinesData.country,
          head_quaters:props.editAirlinesData.head_quaters,
          website:props.editAirlinesData.website,
          slogan:props.editAirlinesData.slogan,
          established:props.editAirlinesData.established
      })
  });

  const onFinish=(values)=>{
      console.log(props.editAirlinesData.id)
      axios.put({
          method:'put',
          url:`https://api.instantwebtools.net/v1/passenger/:${props.editAirlinesData.id}`,
          data:values
      })
      props.setIsEditModalOpen(false);
  }

  const onClickCancel=()=>{
      props.setIsEditModalOpen(false);
  }

  return (
    <>
      <Form form={editForm} onFinish={onFinish}>
        <Row>
          <Col span="12">
            <Form.Item
              name="name"
              label="Name"
              rules={[
                {
                  required: true,
                  message: "Please input your headquaters!",
                },
              ]}
            >
              <Input />
            </Form.Item>
          </Col>

          <Col span="12">
        <Form.Item
          label="Country"
          name="country"
          rules={[
            {
              required: true,
              message: "Please input your country!",
            },
          ]}
        >
            <Input />
        </Form.Item>
          </Col>
        </Row>

        <Row>
          <Col span="12">
          <Form.Item
          label="HeadQuaters"
          name="head_quaters"
          rules={[
            {
              required: true,
              message: "Please input your headquaters!",
            },
          ]}
        >
            <Input />
        </Form.Item>
        
        
          </Col>
          <Col span="12">
          <Form.Item
          label="Website"
          name="website"
          rules={[
            {
              required: true,
              message: "Please input your website!",
            },
          ]}
        >
            <Input />
        </Form.Item>
          </Col>
      </Row>
      <Row>
      <Col span="12">
      <Form.Item
          label="Slogan"
          name="slogan"
          rules={[
            {
              required: false,
            },
          ]}
        >
            <Input />
        </Form.Item>
      </Col>
      <Col span="12">
      <Form.Item
          label="Established"
          name="established"
          rules={[
            {
              required: true,
              message: "Please input your established year!",
            },
          ]}
        >
            <Input />
        </Form.Item>
      </Col>
      </Row>
      <Button type="primary" htmlType="submit" style={{marginLeft:"415px"}}>Edit</Button>
      <Button type="default" onClick={onClickCancel} style={{marginLeft:"10px"}}>Cancel</Button>

      </Form>
    </>
  );
};
export default EditAirlines;
