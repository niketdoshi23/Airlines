import { Button, Checkbox, Form, Input,Row,Col,Card } from "antd";
import axios from "axios";
const CreateAirlines = () => {
    const onFinishForm=(values)=>{
        axios({
            method:'post',
            url:"https://api.instantwebtools.net/v1/airlines",
            data:values
        })
    }
  return (
    <>
    <Card title="Airways Registration" style={{width:600,marginLeft:"400px",marginTop:"180px"}}>
      <Form
        name="airline"
        labelCol={{
          span: 8,
        }}
        wrapperCol={{
          span: 16,
        }}
        style={{
          maxWidth: 600,
        }}
        onFinish={onFinishForm}
      >
      <Row>
          <Col span="12">
        <Form.Item
          label="Name"
          name="name"
          rules={[
            {
              required: true,
              message: "Please input your name!",
            },
          ]}
        >
            <Input />
        </Form.Item>
          </Col>
          <Col span="12">
        <Form.Item
          label="Country"
          name="country"
          rules={[
            {
              required: true,
              message: "Please input your country!",
            },
          ]}
        >
            <Input />
        </Form.Item>
          </Col>
      </Row>
      <Row>
          <Col span="12">
          <Form.Item
          label="HeadQuaters"
          name="head_quaters"
          rules={[
            {
              required: true,
              message: "Please input your headquaters!",
            },
          ]}
        >
            <Input />
        </Form.Item>
        
        
          </Col>
          <Col span="12">
          <Form.Item
          label="Website"
          name="website"
          rules={[
            {
              required: true,
              message: "Please input your website!",
            },
          ]}
        >
            <Input />
        </Form.Item>
          </Col>
      </Row>
      <Row>
      <Col span="12">
      <Form.Item
          label="Slogan"
          name="slogan"
          rules={[
            {
              required: false,
            },
          ]}
        >
            <Input />
        </Form.Item>
      </Col>
      <Col span="12">
      <Form.Item
          label="Established"
          name="established"
          rules={[
            {
              required: true,
              message: "Please input your established year!",
            },
          ]}
        >
            <Input />
        </Form.Item>
      </Col>
      </Row>
      <Button type="primary" htmlType="submit">Submit</Button>
      </Form>
    </Card>
    </>
  );
};

export default CreateAirlines;
