import { Card,Row,Col } from 'antd';
const AirlinesInfo = (props) => {
    // const {airwaysById}=props
    console.log(props.airwaysById);
    return ( 
        <>
        <Card>
        <Row>
            <Col span="12">
            ID:<b>{props.airwaysById.id}</b>
            </Col>
            <Col span="12">
            Name:<b>{props.airwaysById.name}</b>
            </Col>
        </Row>
        <br />
        <Row>
        <Col span="12">
            Established:<b>{props.airwaysById.established}</b>
            </Col>
            <Col span="12">
            Country:<b>{props.airwaysById.country}</b>
            </Col>
        </Row>
        <br />
        <Row>
        <Col span="12">
            Headquaters:<b>{props.airwaysById.head_quaters}</b>
            </Col>
            <Col span="12">
            Slogan:<b>{props.airwaysById.slogan}</b>
            </Col>
        </Row>
        <br />
        <Row>
            <Col span="12">
            Website:<b>{props.airwaysById.website}</b>
            </Col>
        </Row>
        </Card>
        </>
     );
}
 
export default AirlinesInfo;