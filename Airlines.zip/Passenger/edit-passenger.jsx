import { useEffect } from "react";
import { Button, Checkbox, Form, Input, Row, Col } from "antd";
import FormItem from "antd/es/form/FormItem";
import axios from "axios";

const EditPassenger = (props) => {
    const [editForm] = Form.useForm();
    console.log(props.editPassengerData.name);
    useEffect(() => {
        editForm.setFieldsValue({
            name:props.editPassengerData.name,
            trips:props.editPassengerData.trips,
            airline:"8"
        })
    }, [props.editPassengerData]);

    const onFinish=(values)=>{
        values.airline=8;
        axios({
            method:"put",
            url:`https://api.instantwebtools.net/v1/passenger/:${props.editPassengerData.airline[0].id}`,
            data:values
        })
    }
    
    return ( 
        <>
        <Form form={editForm} onFinish={onFinish}>
        <Row>
          <Col span="12">
            <Form.Item
              name="name"
              label="Name"
              rules={[
                {
                  required: true,
                  message: "Please input your name!",
                },
              ]}
            >
              <Input />
            </Form.Item>
          </Col>

          <Col span="12">
        <Form.Item
          label="Trips"
          name="trips"
          rules={[
            {
              required: true,
              message: "Please input your trips!",
            },
          ]}
        >
            <Input />
        </Form.Item>
          </Col>
        </Row>
        <Button type="primary" htmlType="submit" style={{marginLeft:"415px"}}>Edit</Button>
        </Form>
        </>
     );
}
 
export default EditPassenger;