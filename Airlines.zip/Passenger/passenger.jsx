import { Button, Space, Table, Tag, Modal } from "antd";
import axios from "axios";
import { Spin } from "antd";
import { useState,useEffect } from "react";
import PassengersInfo from "./passengers-info";
import { InfoCircleOutlined,DeleteOutlined,EditOutlined } from "@ant-design/icons";
import EditPassenger from "./edit-passenger";

const Passenger = () => {
    const [passengerInfo,setPassengerInfo]=useState([]);
    const [isPassengerInfoAvailable, setIsPassengerInfoAvailable] = useState(false);
    const [passengersById, setPassengersById] = useState({});
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditPassengerModalOpen,setIsEditPassengerModalOpen]=useState(false);
    const [editPassengerData,setEditPassengerData]=useState({});

    const onClickInfo = (data) => {
        setPassengersById(data);
        setIsModalOpen(true);
      };

      const onDeletePassenger=(data)=>{
        console.log(data);
          axios({
            method:"delete",
            url:`https://api.instantwebtools.net/v1/passenger/:${data._id}`
          })
      }

      const handleOk = () => {
        setIsModalOpen(false);
      };
      const handleCancel = () => {
        setIsModalOpen(false);
      };

      const onEditPassenger=(data)=>{
        console.log(data);
        setIsEditPassengerModalOpen(true);
        setEditPassengerData(data);
      }
      const onCalcelEditPassenger=()=>{
        setIsEditPassengerModalOpen(false);
      }

    const column=[
        {
            title:"ID",
            dataIndex:["airline","0","id"],
            key:"id"
        },
        {
            title:"Name",
            dataIndex:["airline","0","name"],
            key:"name"
        },
        {
            title:"Established",
            dataIndex:["airline","0","established"],
            key:"established"
        },
        {
            title:"ID",
            dataIndex:["airline","0","id"],
            key:"id"
        },
        {
            title:"country",
            dataIndex:["airline","0","country"],
            key:"country"
        },
        {
            title:"HeadQuaters",
            dataIndex:["airline","0","head_quaters"],
            key:"id"
        },
        {
            title:"Passenger Name",
            dataIndex:"name",
            key:"pname"
        },
        {
            title:"Passenger ID",
            dataIndex:"_id",
            key:"pid"
        },
        {
            title:"Trips",
            dataIndex:"trips",
            key:"trips"
        },
        {
            title: "Action",
            dataIndex: "action",
            key: "action",
            render: (_, record) => (
              <>
                <Space>
                  <Button
                    icon={<InfoCircleOutlined />}
                    onClick={() => onClickInfo(record)}
                  />
                  <Button icon={<DeleteOutlined />}
                  onClick={()=>onDeletePassenger(record)}
                  />
                  <Button icon={<EditOutlined />} onClick={()=>onEditPassenger(record)} /> 
                </Space>
              </>
            ),
          },
    ];
    useEffect(() => {
        axios
    .get("https://api.instantwebtools.net/v1/passenger?page=0&size=10")
    .then((response) => {
      setIsPassengerInfoAvailable(false);
      if (response) {
        setIsPassengerInfoAvailable(true);
        setPassengerInfo(response?.data?.data);
      }
    })
    .catch((error) => {
      setIsPassengerInfoAvailable(true);
      console.log(error);
    });
    }, [])
    
    return ( 
        <>
        <Table columns={column} dataSource={passengerInfo} />
        <Modal
        title="Airways Information"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <PassengersInfo passengersById={passengersById} />
      </Modal>
      {
        editPassengerData &&
      <Modal open={isEditPassengerModalOpen} footer={false} onCancel={onCalcelEditPassenger}>
      <EditPassenger editPassengerData={editPassengerData}  />
      </Modal>
      }
        </>
     );
}
 
export default Passenger;