import { Card,Row,Col } from 'antd';
const PassengersInfo = (props) => {
    return ( 
        <>
        <Card>
        <Row>
            <Col span="12">
            Name:<b>{props.passengersById.name}</b>
            </Col>
            <Col span="12">
            Trips:<b>{props.passengersById.trips}</b>
            </Col>
        </Row>
        </Card>
        </>
     );
}
 
export default PassengersInfo;